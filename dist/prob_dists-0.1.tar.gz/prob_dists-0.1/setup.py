from setuptools import setup

setup(name='prob_dists',
      version='0.1',
      description='Gaussian distributions',
      packages=['prob_dists'],
      author = 'Malladi,Yeswanth chowdary',
      author_email = 'malladi.yaswanth@gmail.com',
      zip_safe = False)
